package com.example.calculatorpro;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.DecimalFormat;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(16,20,25), PANEL=Color.rgb(28,35,43), KEY=Color.rgb(43,52,62),
            ACC=Color.rgb(53,208,186), WHITE=Color.WHITE, MUTED=Color.rgb(165,178,190);
    LinearLayout root, content;
    String expression="";
    TextView display, hint;
    final DecimalFormat fmt=new DecimalFormat("0.##########");

    @Override public void onCreate(Bundle b){ super.onCreate(b); showHome(); }

    TextView text(String s,int size,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    LinearLayout column(){ LinearLayout l=new LinearLayout(this); l.setOrientation(1); return l; }
    LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(0); l.setGravity(Gravity.CENTER); return l; }
    void base(String title){
        root=column(); root.setBackgroundColor(BG);
        TextView h=text(title,23,WHITE); h.setTypeface(null,Typeface.BOLD); h.setPadding(20,18,12,12);
        root.addView(h,new LinearLayout.LayoutParams(-1,60));
        ScrollView sc=new ScrollView(this); content=column(); content.setPadding(14,4,14,24);
        sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    Button button(String s, Runnable action, int color){
        Button b=new Button(this); b.setText(s); b.setTextSize(17); b.setTextColor(WHITE);
        b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        b.setOnClickListener(v->action.run()); return b;
    }
    void showHome(){
        base("Калькулятор PRO");
        TextView intro=text("Универсальный калькулятор",17,MUTED); intro.setPadding(8,8,8,18); content.addView(intro);
        addMenu("Обычный калькулятор","Арифметика, скобки и история",()->showBasic());
        addMenu("Инженерный","sin, cos, tan, √, ln, log, степени",()->showScientific());
        addMenu("Проценты","Найти процент, скидку и наценку",()->showPercent());
        addMenu("Конвертер величин","Длина, масса, температура, объём",()->showConverter());
        addMenu("Автомобильный","Расход топлива и стоимость поездки",()->showCar());
        addMenu("Финансовый","Кредит и переплата",()->showLoan());
        addMenu("Время","Перевод часов, минут и секунд",()->showTime());
        TextView foot=text("Работает офлайн • Версия 1.0",13,MUTED); foot.setGravity(Gravity.CENTER); foot.setPadding(0,20,0,8); content.addView(foot);
    }
    void addMenu(String title,String sub,Runnable r){
        LinearLayout card=column(); card.setBackgroundColor(PANEL); card.setPadding(16,10,16,10);
        TextView a=text(title,19,WHITE); a.setTypeface(null,Typeface.BOLD); card.addView(a);
        TextView d=text(sub,13,MUTED); card.addView(d);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,76); p.setMargins(0,5,0,7);
        content.addView(card,p); card.setOnClickListener(v->r.run());
    }
    void backButton(){
        content.addView(button("← На главную",()->showHome(),KEY),new LinearLayout.LayoutParams(-1,52));
    }
    void showBasic(){
        base("Обычный калькулятор"); backButton();
        display=text("0",38,WHITE); display.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        display.setPadding(8,12,8,12); display.setBackgroundColor(PANEL);
        content.addView(display,new LinearLayout.LayoutParams(-1,100));
        hint=text("Выражение",13,MUTED); content.addView(hint);
        String[][] keys={{"AC","⌫","(",")"},{"7","8","9","÷"},{"4","5","6","×"},{"1","2","3","−"},{"0",".","^","+"},{"%","√","=",""}};
        for(String[] line:keys){
            LinearLayout r=row();
            for(String k:line){ if(k.isEmpty()) continue;
                int c=(k.equals("=")||"+−×÷".contains(k))?Color.rgb(29,128,118):KEY;
                Button bt=button(k,()->tap(k),c);
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,58,1); p.setMargins(3,3,3,3); r.addView(bt,p);
            }
            content.addView(r);
        }
        TextView hist=text("История вычислений сохраняется в текущем сеансе.",12,MUTED); hist.setPadding(5,12,5,5); content.addView(hist);
    }
    void tap(String k){
        if(k.equals("AC")) expression="";
        else if(k.equals("⌫")){ if(!expression.isEmpty()) expression=expression.substring(0,expression.length()-1); }
        else if(k.equals("=")){
            try { double v=new Parser(expression).parse(); expression=fmt.format(v); hint.setText("Результат"); }
            catch(Exception e){ hint.setText("Проверь выражение"); }
        } else if(k.equals("√")) expression+="sqrt(";
        else if(k.equals("÷")) expression+="/";
        else if(k.equals("×")) expression+="*";
        else if(k.equals("−")) expression+="-";
        else if(k.equals("%")) expression+="/100";
        else expression+=k;
        display.setText(expression.isEmpty()?"0":expression);
    }
    void showScientific(){
        base("Инженерный калькулятор"); backButton();
        EditText in=field("Число"); content.addView(in);
        Spinner sp=spinner(new String[]{"sin (градусы)","cos (градусы)","tan (градусы)","√ квадратный корень","x² квадрат","ln натуральный логарифм","log десятичный логарифм"});
        content.addView(sp);
        TextView out=resultBox(); content.addView(out);
        content.addView(button("Вычислить",()->{try{double x=Double.parseDouble(in.getText().toString()); int n=sp.getSelectedItemPosition(); double y;
            switch(n){case 0:y=Math.sin(Math.toRadians(x));break;case 1:y=Math.cos(Math.toRadians(x));break;case 2:y=Math.tan(Math.toRadians(x));break;case 3:y=Math.sqrt(x);break;case 4:y=x*x;break;case 5:y=Math.log(x);break;default:y=Math.log10(x);}
            out.setText(fmt.format(y));}catch(Exception e){out.setText("Неверное значение");}},ACC));
    }
    EditText field(String s){ EditText e=new EditText(this); e.setSingleLine(true); e.setHint(s); e.setTextColor(WHITE); e.setHintTextColor(MUTED); e.setTextSize(18); e.setPadding(14,8,14,8); e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(ACC)); return e; }
    TextView resultBox(){ TextView t=text("Результат появится здесь",20,ACC); t.setPadding(12,18,12,18); return t; }
    Spinner spinner(String[] vals){ Spinner s=new Spinner(this); ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,vals); s.setAdapter(a); return s; }
    double val(EditText e){return Double.parseDouble(e.getText().toString().replace(',','.'));}
    void showPercent(){
        base("Калькулятор процентов"); backButton();
        EditText a=field("Сумма / исходное число"), b=field("Процент (%)");
        content.addView(a); content.addView(b); Spinner sp=spinner(new String[]{"Найти процент от числа","Добавить процент к числу","Вычесть процент (скидка)"}); content.addView(sp);
        TextView out=resultBox(); content.addView(out);
        content.addView(button("Рассчитать",()->{try{double x=val(a),p=val(b),z=x*p/100; int n=sp.getSelectedItemPosition(); out.setText(fmt.format(n==0?z:n==1?x+z:x-z));}catch(Exception e){out.setText("Заполни оба поля");}},ACC));
    }
    void showConverter(){
        base("Конвертер величин"); backButton();
        EditText a=field("Значение"); content.addView(a);
        Spinner type=spinner(new String[]{"Длина: метры → километры","Длина: километры → метры","Масса: кг → граммы","Масса: граммы → кг","Объём: литры → миллилитры","Объём: мл → литры","Температура: °C → °F","Температура: °F → °C","Площадь: м² → гектары","Площадь: гектары → м²"});
        content.addView(type); TextView out=resultBox(); content.addView(out);
        content.addView(button("Конвертировать",()->{try{double x=val(a),y; switch(type.getSelectedItemPosition()){
            case 0:y=x/1000;break;case 1:y=x*1000;break;case 2:y=x*1000;break;case 3:y=x/1000;break;case 4:y=x*1000;break;case 5:y=x/1000;break;case 6:y=x*9/5+32;break;case 7:y=(x-32)*5/9;break;case 8:y=x/10000;break;default:y=x*10000;}
            out.setText(fmt.format(y));}catch(Exception e){out.setText("Введи число");}},ACC));
    }
    void showCar(){
        base("Автомобильный калькулятор"); backButton();
        EditText distance=field("Расстояние (км)"), consumption=field("Расход (л / 100 км)"), price=field("Цена топлива за литр");
        content.addView(distance); content.addView(consumption); content.addView(price); TextView out=resultBox(); content.addView(out);
        content.addView(button("Рассчитать поездку",()->{try{double litres=val(distance)*val(consumption)/100, cost=litres*val(price); out.setText("Топливо: "+fmt.format(litres)+" л\nСтоимость: "+fmt.format(cost));}catch(Exception e){out.setText("Заполни все поля");}},ACC));
    }
    void showLoan(){
        base("Финансовый калькулятор"); backButton();
        EditText sum=field("Сумма кредита"), rate=field("Годовая ставка (%)"), months=field("Срок (месяцев)");
        content.addView(sum); content.addView(rate); content.addView(months); TextView out=resultBox(); content.addView(out);
        content.addView(button("Рассчитать платёж",()->{try{double p=val(sum),r=val(rate)/1200,n=val(months),pay=r==0?p/n:p*r/(1-Math.pow(1+r,-n)); out.setText("Платёж в месяц: "+fmt.format(pay)+"\nВсего: "+fmt.format(pay*n)+"\nПереплата: "+fmt.format(pay*n-p));}catch(Exception e){out.setText("Проверь введённые данные");}},ACC));
        TextView note=text("Расчёт ориентировочный: без комиссий, страховок и дополнительных платежей.",12,MUTED); content.addView(note);
    }
    void showTime(){
        base("Калькулятор времени"); backButton();
        EditText v=field("Количество"); content.addView(v);
        Spinner sp=spinner(new String[]{"Часы → минуты","Минуты → секунды","Секунды → минуты","Минуты → часы","Часы → секунды","Секунды → часы"}); content.addView(sp);
        TextView out=resultBox(); content.addView(out);
        content.addView(button("Перевести",()->{try{double x=val(v),y; switch(sp.getSelectedItemPosition()){case 0:y=x*60;break;case 1:y=x*60;break;case 2:y=x/60;break;case 3:y=x/60;break;case 4:y=x*3600;break;default:y=x/3600;} out.setText(fmt.format(y));}catch(Exception e){out.setText("Введи число");}},ACC));
    }

    static class Parser {
        String s; int pos=-1,ch;
        Parser(String s){this.s=s;}
        void next(){ch=(++pos<s.length())?s.charAt(pos):-1;}
        boolean eat(int c){while(ch==' ')next(); if(ch==c){next();return true;}return false;}
        double parse(){next(); double x=expr(); if(pos<s.length())throw new RuntimeException(); return x;}
        double expr(){double x=term(); for(;;){if(eat('+'))x+=term();else if(eat('-'))x-=term();else return x;}}
        double term(){double x=power();for(;;){if(eat('*'))x*=power();else if(eat('/')){double d=power();if(d==0)throw new ArithmeticException();x/=d;}else return x;}}
        double power(){double x=factor();if(eat('^'))x=Math.pow(x,power());return x;}
        double factor(){
            if(eat('+'))return factor(); if(eat('-'))return -factor();
            double x; int start=pos;
            if(eat('(')){x=expr();if(!eat(')'))throw new RuntimeException();return x;}
            if((ch>='0'&&ch<='9')||ch=='.'){while((ch>='0'&&ch<='9')||ch=='.')next();x=Double.parseDouble(s.substring(start,pos));return x;}
            if(ch>='a'&&ch<='z'){while(ch>='a'&&ch<='z')next();String f=s.substring(start,pos);if(f.equals("pi"))return Math.PI;if(f.equals("e"))return Math.E;
                if(!eat('('))throw new RuntimeException();x=expr();if(!eat(')'))throw new RuntimeException();
                switch(f){case "sqrt":return Math.sqrt(x);case "sin":return Math.sin(Math.toRadians(x));case "cos":return Math.cos(Math.toRadians(x));case "tan":return Math.tan(Math.toRadians(x));case "ln":return Math.log(x);case "log":return Math.log10(x);default:throw new RuntimeException();}}
            throw new RuntimeException();
        }
    }
}
